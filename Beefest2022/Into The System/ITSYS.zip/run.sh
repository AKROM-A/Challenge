#! /bin/bash
cd /home/ctf/ && ./ITSYS
